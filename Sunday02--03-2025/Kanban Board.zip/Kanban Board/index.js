document.addEventListener("DOMContentLoaded", () => {
    let draggedCard = null;

    function addDragEvents(card) {
        card.addEventListener("dragstart", () => {
            draggedCard = card;
            card.classList.add("dragging");
            setTimeout(() => (card.style.opacity = "0.5"), 0);
        });

        card.addEventListener("dragend", () => {
            draggedCard = null;
            card.classList.remove("dragging");
            card.style.opacity = "1";
        });
    }

 
    document.querySelectorAll(".card").forEach(addDragEvents);

    
    document.querySelectorAll(".cards").forEach((cardsContainer) => {
        cardsContainer.addEventListener("dragover", (e) => {
            e.preventDefault();
            cardsContainer.classList.add("drag-over");
        });

        cardsContainer.addEventListener("dragleave", () => {
            cardsContainer.classList.remove("drag-over");
        });

        cardsContainer.addEventListener("drop", () => {
            if (draggedCard) {
                cardsContainer.appendChild(draggedCard);
                draggedCard.style.opacity = "1";
                draggedCard.classList.remove("dragging");
                draggedCard = null;
            }
            cardsContainer.classList.remove("drag-over");
        });
    });
});


function addTask(columnId) {
    const taskText = prompt("Enter the task:").trim();
    if (taskText) {
        const column = document.getElementById(columnId).querySelector(".cards");
        const newCard = document.createElement("div");
        newCard.className = "card";
        newCard.draggable = true;
        newCard.textContent = taskText;
        column.appendChild(newCard);

       
        addDragEvents(newCard);
    }
}
